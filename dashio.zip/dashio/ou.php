<?php
class ou{

    private $nombre;
    private $descripcion;

    function getNombre(){
        return $this->nombre;
    }
    function getDescripcion(){
        return $this->descripcion;
    }
    function setNombre($nombre){
        $this->nombre = $nombre;
    }
    function setDescripcion($descripcion){
        $this->descripcion = $descripcion;
    }
    function getLDAPInfo(){
        $info['objectClass'][0] = "top";
        $info['objectClass'][1] = "organizationalUnit";
        $info['ou'] = $this->nombre;
        $info['description'] = $this->descripcion;
        return $info;
    }

    public function __construct($nombre){
        $this->nombre = $nombre;
        $this->descripcion = "Unidad organizativa de " . $this->getNombre();
    }
}

?>