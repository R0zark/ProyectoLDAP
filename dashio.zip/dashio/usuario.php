<?php
class Usuario{

    private $id;
    private $usuario;
    private $nombre;
    private $apellidos;
    private $idgrupo;

    function getId(){
        return $this->id;
    }
    function getUsuario(){
        return $this->usuario;
    }
    function getNombre(){
        return $this->nombre;
    }
    function getApellidos(){
        return $this->apellidos;
    }
    function getIdGrupo(){
        return $this->idgrupo;
    }
    function setId($id){
        $this->id = $id;
    }
    function setUsuario($usuario){
        $this->usuario = $usuario;
    }
    function setNombre($nombre){
        $this->nombre = $nombre;
    }
    function setApellidos($apellidos){
        $this->apellidos = $apellidos;
    }
    function setIdGrupo($idgrupo){
        $this->idgrupo = $idgrupo;
    }
    function getLDAPInfo(){
        $info['objectClass'][0] = "inetOrgPerson";
        $info['objectClass'][1] = "posixAccount";
        $info['cn'] = $this->getNombre();
        $info['sn'] = $this->getApellidos();
        $info['uid'] = $this->getUsuario();
        $info['uidNumber'] = $this->getId();
        $info['gidNumber'] = $this->getIdGrupo();
        $info['loginShell'] = "/bin/bash";
        $info['homeDirectory'] = "/home/".$this->getUsuario()."";
        return $info;
    }
    public function __construct($id,$usuario,$nombre,$apellidos,$idgrupo){
        $this->id = $id;
        $this->usuario = $usuario;
        $this->nombre = $nombre;
        $this->apellidos = $apellidos;
        $this->idgrupo = $idgrupo;
    }
}
?>