<?php
class grupo{
    private $nombre;
    private $idgrupo;
    private $ou;

    function getNombre(){
        return $this->nombre;
    }
    function getIdGrupo(){
        return $this->idgrupo;
    }
    function getOU(){
        return $this->ou;
    }
    function setNombre($nombre){
        $this->nombre = $nombre;
    }
    function setIdGrupo($idgrupo){
        $this->idgrupo = $idgrupo;
    }
    function setOU($ou){
        $this->ou = $ou;
    }
    function getLDAPInfo(){
        $info['objectClass'] = "posixGroup";
        $info['cn'] = $this->getNombre();
        $info['gidNumber'] = $this->getIdGrupo();
        return $info;
    }
}
?>