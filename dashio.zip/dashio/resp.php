<?php 
require('ou.php');//funciona
require('usuario.php');
require('grupo.php');

$resultado = $_POST['usuario'] . $_POST['nombre']; 
echo $resultado;




?>